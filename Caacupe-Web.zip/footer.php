

		<!-- FOOTER -->
		<div class="footer">
			<div class="container">
				<div class="row center-xs between-xs">
					<div class="col-xs-3">
					</div>
					<div class="col-xs-3"></div>
					<div class="col-xs-12 copyright">Todos los derechos reservados - &copy; Caacup&eacute; Web 2016 - Design By: Matias Baez</div>
				</div>
			</div>
		</div>
		<!-- FIN FOOTER -->

	</div> <!-- FIN CONTENEDOR -->

		<?php wp_footer(); ?>
	</body>
</html>